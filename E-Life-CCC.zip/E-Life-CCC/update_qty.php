<?php
$Product_id = isset($_GET['Pro_id']) ? $_GET['Pro_id'] : 1;
$Quantity = isset($_GET['Quantity']) ? $_GET['Quantity'] : "";
include 'config/database.php';
$Quantity=$Quantity<=0 ? 1 : $Quantity;
include_once "object/cart_items.php";
$database = new Database();
$db = $database->getConnection();
$cart_items = new CartItem($db);
$cart_items->user_id=1;
$cart_items->Product_id=$Product_id;
$cart_items->Quantity=$Quantity;
if($cart_items->update()){
    header("Location: cart.php?action=updated");
}else{
    header("Location: cart.php?action=unable_to_update");
}
?>