<?php
class ProductImage{
 
    // database connection and table name
    private $conn;
    private $table_name = "product_images";
 
    // object properties
    public $Id;
    public $Product_id;
    public $image_name;
    public function __construct($db){
        $this->conn = $db;

    }
function readByProductId(){
    $query = "SELECT Id, Product_id, image_name
            FROM " . $this->table_name . "
            WHERE Product_id = ?
            ORDER BY image_name ASC";
    $stmt = $this->conn->prepare( $query );
    $this->Product_id=htmlspecialchars(strip_tags($this->Product_id));
    $stmt->bindParam(1, $this->Product_id);
    $stmt->execute();
    return $stmt;
}
    function readFirst(){
    $query = "SELECT Id, Product_id, image_name
            FROM " . $this->table_name . "
            WHERE Product_id = ?
            ORDER BY name DESC
            LIMIT 0, 1";
    $stmt = $this->conn->prepare( $query );
    $this->Id=htmlspecialchars(strip_tags($this->Id));
    $stmt->bindParam(1, $this->Product_id);
    $stmt->execute();
    return $stmt;
}

}