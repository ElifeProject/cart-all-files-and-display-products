<?php
class Product{
    private $conn;
    private $table_name = "product_details";
    // object properties
    public $Pro_id;
    public $Pro_name;
    public $price;  
    public $cat_id;
    public function __construct($db){
        $this->conn = $db;
    }
    // create product
    function create(){
 
        //write query
        $query = "INSERT INTO
                    " . $this->table_name . "
                SET
                    Pro_name=:Pro_name, price=:price,  cat_id=:cat_id, image=:image";
 
        $stmt = $this->conn->prepare($query);
 
        // posted values
        $this->Pro_name=htmlspecialchars(strip_tags($this->Pro_name));
        $this->price=htmlspecialchars(strip_tags($this->price));
    
        $this->cat_id=htmlspecialchars(strip_tags($this->cat_id));
 
        // bind values 
        $stmt->bindParam(":Pro_name", $this->Pro_name);
        $stmt->bindParam(":price", $this->price);

        $stmt->bindParam(":cat_id", $this->cat_id);
        
 
        if($stmt->execute()){
            return true;
        }else{
            return false;
        }
 
    }
    public function readAll($from_record_num, $records_per_page){
 
    $query = "SELECT
                Pro_id,Pro_name, price, cat_id
            FROM
                " . $this->table_name . "
            ORDER BY
                Pro_id ASC
            LIMIT
                {$from_record_num}, {$records_per_page}";
 
    $stmt = $this->conn->prepare($query);
    $stmt->execute();
    //echo"Hello";
    return $stmt;

    }
    
    public function countAll(){
 
    $query = "SELECT Pro_id  FROM " . $this->table_name . " ";
 
    $stmt = $this->conn->prepare( $query );
    $stmt->execute();
 
    $num = $stmt->rowCount();
    return $num;
}
    public function readOne(){
    //echo "hi";
    $query = "SELECT
                Pro_name, price, cat_id
            FROM
                " . $this->table_name . "
            WHERE
                Pro_id = ?
            LIMIT
                0,1";
 
    $stmt = $this->conn->prepare( $query );
    $stmt->bindParam(1, $this->Pro_id);
    $stmt->execute();
 
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
 
    $this->Pro_name = $row['Pro_name'];
    $this->price = $row['price'];
    $this->cat_id = $row['cat_id'];
    //return $row;
}
public function update(){
 
    $query = "UPDATE
                " . $this->table_name . "
            SET
                Pro_name = :Pro_name,
                price = :price,  
                cat_id  = :cat_id
            WHERE
                Pro_id = :Pro_id";
    $stmt = $this->conn->prepare($query);
 
    // posted values
    $this->Pro_name=htmlspecialchars(strip_tags($this->Pro_name));
    $this->price=htmlspecialchars(strip_tags($this->price));
    $this->cat_id=htmlspecialchars(strip_tags($this->cat_id));
    $this->Pro_id=htmlspecialchars(strip_tags($this->Pro_id));
 
    // bind parameters
    $stmt->bindParam(':Pro_name', $this->Pro_name);
    $stmt->bindParam(':price', $this->price);
    $stmt->bindParam(':cat_id', $this->cat_id);
    $stmt->bindParam(':Pro_id', $this->Pro_id);
 
    // execute the query
    if($stmt->execute()){
        return true;
    }
    return false;    
}
function read($from_record_num, $records_per_page){
 
    // select all products query
    $query = "SELECT
                Pro_id, Pro_name, price 
            FROM
                " . $this->table_name . "
            ORDER BY
                created DESC
            LIMIT
                ?, ?";
 
    // prepare query statement
    $stmt = $this->conn->prepare( $query );
 
    // bind limit clause variables
    $stmt->bindParam(1, $from_record_num, PDO::PARAM_INT);
    $stmt->bindParam(2, $records_per_page, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt;
}
 
public function readByIds($ids){
 
    $ids_arr = str_repeat('?,', count($ids) - 1) . '?';
    $query = "SELECT Pro_id, Pro_name, price, FROM " . $this->table_name . " WHERE Pro_id IN ({$ids_arr}) ORDER BY Pro_name";
    $stmt = $this->conn->prepare($query);
    $stmt->execute($ids);
    return $stmt;
}
public function count(){
 
    // query to count all product records
    $query = "SELECT count(*) FROM " . $this->table_name;
 
    // prepare query statement
    $stmt = $this->conn->prepare( $query );
 
    // execute query
    $stmt->execute();
 
    // get row value
    $rows = $stmt->fetch(PDO::FETCH_NUM);
 
    // return count
    return $rows[0];
}
function readOne(){
    $query = "SELECT
                Pro_name, price
            FROM
                " . $this->table_name . "
            WHERE
                Pro_id = ?
            LIMIT
                0,1";
    $stmt = $this->conn->prepare( $query );
    $this->Pro_id=htmlspecialchars(strip_tags($this->Pro_id));
    $stmt->bindParam(1, $this->Pro_id);
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    $this->Pro_name = $row['Pro_name'];
    $this->price = $row['price'];
}
  function delete()
    {

        $query = "DELETE FROM " . $this->table_name . "WHERE Pro_id= ? ";
 
        $stmt = $this->conn->prepare( $query );
        $stmt->bindParam(1, $this->Pro_id);
        if($result=$stmt->execute()){
            return true;
        }
        else
        {
            return false;
        }    
    }
}
?>