<?php
include_once "config/database.php";
include_once "object/product.php";
include_once "object/pro_image.php";
include_once "object/cart_items.php";
$database = new Database();
$db = $database->getConnection();
$product = new Product($db);
$pro_image = new ProductImage($db);
$Pro_id = isset($_GET['Pro_id']) ? $_GET['Pro_id'] : die('ERROR: Sorry! there is missing ID.');
$action = isset($_GET['action']) ? $_GET['action'] : "";
$product->Pro_id = $Pro_id;
$product->readOne();
$page_title = $product->Pro_name;
$cart_items = new CartItem($db);
$Pro_id = isset($_GET['Pro_id']) ? $_GET['Pro_id'] : die('ERROR: Sorry! there is missing ID.');
$action = isset($_GET['action']) ? $_GET['action'] : "";
$product->Pro_id = $Pro_id;
$product->readOne();
$page_title = $product->Pro_name;
include_once 'layout_header.php';
echo "<div class='col-md-12'>";
    if($action=='added'){
        echo "<div class='alert alert-info'>";
            echo "Woah! Product was added to your cart!";
        echo "</div>";
    }
    else if($action=='unable_to_add'){
        echo "<div class='alert alert-info'>";
            echo "Sorry! Unable to add product to cart.Please Try again.";
        echo "</div>";
    }
echo "</div>";
$pro_image->Product_id=$Pro_id;
$stmt_pro_image = $pro_image->readByProductId();
$num_pro_image = $stmt_pro_image->rowCount();
echo "<div class='col-md-1'>";
    if($num_pro_image>0){
        while ($row = $stmt_pro_image->fetch(PDO::FETCH_ASSOC)){
            $pro_image_name = $row['image_name'];
            $src="uploads/img/{$pro_image_name}";
            echo "<img src='{$src}' class='product-img-thumb' data-img-id='{$row['Id']}' />";
        }
    }else{ echo "No image found."; }
echo "</div>";
include_once 'layout_footer.php';
?>