<?php
// parameters
$Product_id = isset($_GET['Product_id']) ? $_GET['Product_id'] : "";
$Quantity = isset($_GET['Quantity']) ? $_GET['Quantity'] : 1;
 
// make quantity a minimum of 1
$Quantity=$Quantity<=0 ? 1 : $Quantity;
include 'config/database.php';
include_once "object/cart_items.php";
 
// get database connection
$database = new Database();
$db = $database->getConnection();
 
// initialize objects
$cart_items = new CartItem($db);
 

$cart_items->user_id=1; 
$cart_items->Product_id=$Product_id;
$cart_items->Quantity=$Quantity;
if($cart_items->exists()){
    header("Location: cart.php?action=exists");
}
else{
    if($cart_items->create()){
        header("Location: product.php?id={$Product_id}&action=added");
    }else{
        header("Location: product.php?id={$Product_id}&action=unable_to_add");
    }
}
?>