<?php
include_once "config/database.php";
include_once "object/cart_items.php";
$database = new Database();
$db = $database->getConnection();
$cart_items = new CartItem($db);
$cart_items->user_id=1; 
$cart_items->deleteByUser();
$page_title="Thank You for shopping here! Please come again!";
include_once 'layout_head.php';
echo "<div class='col-md-12'>";
    echo "<div class='alert alert-success'>";
        echo "<strong>Your order has been placed successfully!</strong> Thank You for shopping here!";
    echo "</div>";
echo "</div>";
include_once 'layout_foot.php';
?>