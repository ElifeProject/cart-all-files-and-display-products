<?php

//show error reporting
error_reporting(E_ALL);

//start session
session_start();

//home page url
//$home_url = C:\xampp\htdocs\trial\E-Life-CCC\;
$home_url="http://localhost/trial/E-Life-CCC/login.php";

//page given in url parameter(default page is):
$page = isset($_GET['page']) ?$_GET['page'] :1;

//set number of recors on page
$records_per_page = 5 ;

//calculate query 
$from_record_num = ($records_per_page * $page) - $records_per_page;

?>