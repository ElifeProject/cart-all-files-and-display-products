<?php
 
$title = "products";
include 'config/database.php';
include_once "object/cart_items.php";
include_once "object/product.php";
include_once "object/pro_image.php";

$database = new Database();
$db = $database->getConnection();
$product = new Product($db);
$pro_image = new ProductImage($db);
$cart_items = new CartItem($db);
include 'layout_head.php';
$action = isset($_GET['action']) ? $_GET['action'] : "";
$page = isset($_GET['page']) ? $_GET['page'] : 1; 
$records_per_page = 6;
$from_record_num = ($records_per_page * $page) - $records_per_page; 
$stmt=$product->read($from_record_num, $records_per_page);
$num = $stmt->rowCount();
if($num>0){
    $page_url="products.php?";
    $total_rows=$product->count();
    include_once "read_products_template.php";
}
else{
    echo "<div class='col-md-12'>";
        echo "<div class='alert alert-danger'>OOPS!!! No products found :(</div>";
    echo "</div>";
}
include 'layout_foot.php';
?>